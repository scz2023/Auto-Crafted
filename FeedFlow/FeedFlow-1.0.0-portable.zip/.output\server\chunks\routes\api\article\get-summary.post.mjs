import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { u as useDatabase } from '../../../_/database.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';
import 'fs';

const getSummary_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { articleId } = body;
  if (!articleId) {
    throw createError({
      statusCode: 400,
      message: "Article ID is required"
    });
  }
  try {
    const db = useDatabase();
    const stmt = db.prepare("SELECT ai_summary FROM articles WHERE id = ?");
    const article = stmt.get(articleId);
    if (!article) {
      throw createError({
        statusCode: 404,
        message: "Article not found"
      });
    }
    return {
      success: true,
      summary: article.ai_summary || null
    };
  } catch (error) {
    throw createError({
      statusCode: 500,
      message: error.message || "Failed to get summary"
    });
  }
});

export { getSummary_post as default };
//# sourceMappingURL=get-summary.post.mjs.map
