import Database from 'better-sqlite3';
import { join, dirname } from 'path';
import { existsSync, mkdirSync } from 'fs';

let dbInstance = null;
function useDatabase() {
  if (dbInstance) {
    return dbInstance;
  }
  try {
    let dbPath;
    const cwd = process.cwd();
    const isInOutput = cwd.includes(".output") || cwd.includes("server");
    if (isInOutput || process.env.TAURI_PLATFORM) {
      let appDataDir;
      if (process.platform === "win32") {
        appDataDir = process.env.APPDATA || join(process.env.USERPROFILE || process.env.HOME || "", "AppData", "Roaming");
      } else if (process.platform === "darwin") {
        appDataDir = join(process.env.HOME || "", "Library", "Application Support");
      } else {
        appDataDir = join(process.env.HOME || "", ".config");
      }
      dbPath = join(appDataDir, "FeedFlow", "rss-reader.db");
    } else {
      let projectRoot = cwd;
      if (cwd.includes(".output")) {
        projectRoot = join(cwd, "..", "..");
      }
      dbPath = join(projectRoot, "rss-reader.db");
    }
    console.log("Initializing database at:", dbPath);
    console.log("Environment:", { cwd, platform: process.platform, isInOutput });
    const dbDir = dirname(dbPath);
    if (!existsSync(dbDir)) {
      mkdirSync(dbDir, { recursive: true });
    }
    dbInstance = new Database(dbPath, {
      // 设置超时时间，避免数据库锁定
      timeout: 5e3,
      // 启用 WAL 模式以提高并发性能
      verbose: false ? console.log : void 0
    });
    dbInstance.pragma("foreign_keys = ON");
    try {
      dbInstance.pragma("journal_mode = WAL");
    } catch {
    }
    initDatabase(dbInstance);
    console.log("Database initialized successfully");
    return dbInstance;
  } catch (error) {
    console.error("Failed to initialize database:", error);
    console.error("Error stack:", error.stack);
    dbInstance = null;
    throw new Error(`Database initialization failed: ${error.message || "Unknown error"}`);
  }
}
function initDatabase(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS categories (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      description TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP
    )
  `);
  db.exec(`
    CREATE TABLE IF NOT EXISTS feeds (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      url TEXT NOT NULL UNIQUE,
      description TEXT,
      favicon TEXT,
      category_id INTEGER,
      last_update TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
    )
  `);
  try {
    db.exec(`ALTER TABLE feeds ADD COLUMN favicon TEXT`);
  } catch {
  }
  try {
    db.exec(`ALTER TABLE feeds ADD COLUMN category_id INTEGER`);
    try {
      db.exec(`CREATE INDEX IF NOT EXISTS idx_feeds_category_id ON feeds(category_id)`);
    } catch {
    }
  } catch {
  }
  try {
    db.exec(`ALTER TABLE feeds ADD COLUMN is_subscribed INTEGER DEFAULT 1`);
    db.exec(`UPDATE feeds SET is_subscribed = 1 WHERE is_subscribed IS NULL`);
  } catch {
  }
  db.exec(`
    CREATE TABLE IF NOT EXISTS articles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      feed_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      link TEXT,
      content TEXT,
      snippet TEXT,
      pub_date TEXT,
      guid TEXT,
      is_favorite INTEGER DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (feed_id) REFERENCES feeds(id) ON DELETE CASCADE,
      UNIQUE(feed_id, guid)
    )
  `);
  try {
    db.exec(`ALTER TABLE articles ADD COLUMN is_favorite INTEGER DEFAULT 0`);
  } catch {
  }
  try {
    const tableInfo = db.prepare(`PRAGMA table_info(articles)`).all();
    const hasAiSummary = tableInfo.some((col) => col.name === "ai_summary");
    if (!hasAiSummary) {
      db.exec(`ALTER TABLE articles ADD COLUMN ai_summary TEXT`);
      console.log("Added ai_summary column to articles table");
    }
  } catch (error) {
    try {
      db.exec(`ALTER TABLE articles ADD COLUMN ai_summary TEXT`);
    } catch {
    }
  }
  try {
    const tableInfo = db.prepare(`PRAGMA table_info(articles)`).all();
    const columnNames = tableInfo.map((col) => col.name);
    if (!columnNames.includes("title_translated")) {
      db.exec(`ALTER TABLE articles ADD COLUMN title_translated TEXT`);
      console.log("Added title_translated column to articles table");
    }
    if (!columnNames.includes("content_translated")) {
      db.exec(`ALTER TABLE articles ADD COLUMN content_translated TEXT`);
      console.log("Added content_translated column to articles table");
    }
    if (!columnNames.includes("detected_language")) {
      db.exec(`ALTER TABLE articles ADD COLUMN detected_language TEXT`);
      console.log("Added detected_language column to articles table");
    }
  } catch (error) {
    try {
      db.exec(`ALTER TABLE articles ADD COLUMN title_translated TEXT`);
    } catch {
    }
    try {
      db.exec(`ALTER TABLE articles ADD COLUMN content_translated TEXT`);
    } catch {
    }
    try {
      db.exec(`ALTER TABLE articles ADD COLUMN detected_language TEXT`);
    } catch {
    }
  }
  db.exec(`
    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT
    )
  `);
  db.exec(`
    CREATE INDEX IF NOT EXISTS idx_articles_feed_id ON articles(feed_id);
    CREATE INDEX IF NOT EXISTS idx_articles_pub_date ON articles(pub_date);
  `);
}

export { useDatabase as u };
//# sourceMappingURL=database.mjs.map
