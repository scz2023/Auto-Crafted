import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { u as useDatabase } from '../../../_/database.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';
import 'fs';

const translate_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l, _m;
  const body = await readBody(event);
  const { articleId, translateTitleOnly, translateContentOnly } = body;
  if (!articleId) {
    throw createError({
      statusCode: 400,
      message: "Article ID is required"
    });
  }
  try {
    const db = useDatabase();
    const stmt = db.prepare("SELECT id, title, content, snippet, title_translated, content_translated, detected_language FROM articles WHERE id = ?");
    const article = stmt.get(articleId);
    if (!article) {
      throw createError({
        statusCode: 404,
        message: "Article not found"
      });
    }
    const settingsStmt = db.prepare("SELECT value FROM settings WHERE key = ?");
    const settingsRow = settingsStmt.get("aiSettings");
    let aiSettings = null;
    if (settingsRow) {
      try {
        aiSettings = JSON.parse(settingsRow.value);
      } catch {
      }
    }
    if (!aiSettings || !aiSettings.apiToken || !aiSettings.model) {
      throw createError({
        statusCode: 400,
        message: "AI settings not configured. Please configure AI settings first."
      });
    }
    const generalSettingsRow = settingsStmt.get("general");
    const aiTranslationRow = settingsStmt.get("aiTranslation");
    const aiOutputLanguageRow = settingsStmt.get("aiOutputLanguage");
    const translationPreferenceRow = settingsStmt.get("translationPreference");
    console.log("\u7FFB\u8BD1 API - \u8BBE\u7F6E\u8BFB\u53D6:", {
      generalSettingsRow: generalSettingsRow ? "\u5B58\u5728" : "\u4E0D\u5B58\u5728",
      aiTranslationRow: aiTranslationRow ? `\u503C: ${aiTranslationRow.value}` : "\u4E0D\u5B58\u5728",
      aiOutputLanguageRow: aiOutputLanguageRow ? `\u503C: ${aiOutputLanguageRow.value}` : "\u4E0D\u5B58\u5728",
      translationPreferenceRow: translationPreferenceRow ? `\u503C: ${translationPreferenceRow.value}` : "\u4E0D\u5B58\u5728"
    });
    let aiTranslationEnabled = false;
    let targetLanguage = "en";
    let translationPreference = "bilingual";
    if (aiTranslationRow) {
      try {
        const value = JSON.parse(aiTranslationRow.value);
        aiTranslationEnabled = value === true || value === "true" || value === 1;
      } catch {
        aiTranslationEnabled = aiTranslationRow.value === "true" || aiTranslationRow.value === "1";
      }
    }
    if (aiOutputLanguageRow) {
      try {
        targetLanguage = JSON.parse(aiOutputLanguageRow.value) || "en";
      } catch {
        targetLanguage = aiOutputLanguageRow.value || "en";
      }
    }
    if (translationPreferenceRow) {
      try {
        translationPreference = JSON.parse(translationPreferenceRow.value) || "bilingual";
      } catch {
        translationPreference = translationPreferenceRow.value || "bilingual";
      }
    }
    if (!aiTranslationEnabled && generalSettingsRow) {
      try {
        const generalSettings = JSON.parse(generalSettingsRow.value);
        aiTranslationEnabled = generalSettings.aiTranslation === true || generalSettings.aiTranslation === "true" || generalSettings.aiTranslation === 1;
        if (!targetLanguage || targetLanguage === "en") {
          targetLanguage = generalSettings.aiOutputLanguage || "en";
        }
        if (!translationPreference || translationPreference === "bilingual") {
          translationPreference = generalSettings.translationPreference || "bilingual";
        }
      } catch (e) {
        console.error("\u89E3\u6790 general \u8BBE\u7F6E\u5931\u8D25:", e);
      }
    }
    console.log("\u7FFB\u8BD1 API - \u6700\u7EC8\u8BBE\u7F6E:", {
      aiTranslationEnabled,
      targetLanguage,
      translationPreference
    });
    if (!aiTranslationEnabled) {
      throw createError({
        statusCode: 400,
        message: "AI translation is not enabled in settings"
      });
    }
    if (translateTitleOnly) {
      if (article.title_translated && article.detected_language) {
        return {
          success: true,
          titleTranslated: article.title_translated,
          detectedLanguage: article.detected_language,
          cached: true
        };
      }
    }
    if (translateContentOnly) {
      if (article.content_translated && article.detected_language) {
        return {
          success: true,
          contentTranslated: article.content_translated,
          detectedLanguage: article.detected_language,
          cached: true
        };
      }
    }
    if (!translateTitleOnly && !translateContentOnly) {
      if (article.title_translated && article.content_translated && article.detected_language) {
        return {
          success: true,
          titleTranslated: article.title_translated,
          contentTranslated: article.content_translated,
          detectedLanguage: article.detected_language,
          cached: true
        };
      }
    }
    const titleToTranslate = article.title || "";
    const contentToTranslate = article.content || article.snippet || "";
    if (!titleToTranslate && !contentToTranslate) {
      throw createError({
        statusCode: 400,
        message: "Article content is empty"
      });
    }
    const cleanTitle = titleToTranslate.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
    const cleanContent = contentToTranslate.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().substring(0, 15e3);
    const languageNames = {
      "en": "\u82F1\u8BED",
      "ja": "\u65E5\u8BED",
      "ko": "\u97E9\u8BED",
      "fr": "\u6CD5\u8BED",
      "de": "\u5FB7\u8BED",
      "es": "\u897F\u73ED\u7259\u8BED",
      "ru": "\u4FC4\u8BED",
      "it": "\u610F\u5927\u5229\u8BED",
      "pt": "\u8461\u8404\u7259\u8BED",
      "zh": "\u4E2D\u6587"
    };
    const targetLanguageName = languageNames[targetLanguage] || "\u82F1\u8BED";
    const detectPrompt = `\u8BF7\u68C0\u6D4B\u4EE5\u4E0B\u6587\u672C\u7684\u8BED\u8A00\uFF0C\u53EA\u8FD4\u56DE\u8BED\u8A00\u4EE3\u7801\uFF08\u5982\uFF1Azh, en, ja, ko, fr, de, es, ru, it, pt\uFF09\u3002\u5982\u679C\u65E0\u6CD5\u786E\u5B9A\uFF0C\u8FD4\u56DE "unknown"\u3002

\u6587\u672C\uFF1A${cleanTitle.substring(0, 500)}${cleanContent.substring(0, 500)}`;
    let detectedLanguage = "unknown";
    try {
      const detectResponse = await fetch(aiSettings.apiEndpoint || "https://api.siliconflow.cn/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${aiSettings.apiToken}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: aiSettings.model,
          messages: [
            {
              role: "user",
              content: detectPrompt
            }
          ],
          max_tokens: 10,
          temperature: 0.1
        })
      });
      if (detectResponse.ok) {
        const detectData = await detectResponse.json();
        const detected = ((_e = (_d = (_c = (_b = (_a = detectData.choices) == null ? void 0 : _a[0]) == null ? void 0 : _b.message) == null ? void 0 : _c.content) == null ? void 0 : _d.trim()) == null ? void 0 : _e.toLowerCase()) || "unknown";
        if (["zh", "en", "ja", "ko", "fr", "de", "es", "ru", "it", "pt"].includes(detected)) {
          detectedLanguage = detected;
        }
      }
    } catch (error) {
      console.error("Language detection failed:", error);
    }
    if (detectedLanguage === targetLanguage) {
      const updateStmt = db.prepare("UPDATE articles SET detected_language = ? WHERE id = ?");
      updateStmt.run(detectedLanguage, articleId);
      const result = {
        success: true,
        detectedLanguage,
        cached: false,
        noTranslationNeeded: true
      };
      if (translateTitleOnly) {
        result.titleTranslated = article.title;
      } else if (translateContentOnly) {
        result.contentTranslated = article.content || article.snippet || "";
      } else {
        result.titleTranslated = article.title;
        result.contentTranslated = article.content || article.snippet || "";
      }
      return result;
    }
    let titleTranslated = article.title_translated || article.title;
    if (cleanTitle && !translateContentOnly) {
      const titlePrompt = `\u8BF7\u5C06\u4EE5\u4E0B\u6587\u672C\u7FFB\u8BD1\u6210${targetLanguageName}\uFF0C\u53EA\u8FD4\u56DE\u7FFB\u8BD1\u7ED3\u679C\uFF0C\u4E0D\u8981\u6DFB\u52A0\u4EFB\u4F55\u89E3\u91CA\uFF1A

${cleanTitle}`;
      try {
        const titleResponse = await fetch(aiSettings.apiEndpoint || "https://api.siliconflow.cn/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${aiSettings.apiToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model: aiSettings.model,
            messages: [
              {
                role: "user",
                content: titlePrompt
              }
            ],
            max_tokens: aiSettings.maxTokens || 500,
            temperature: aiSettings.temperature || 0.7,
            top_p: aiSettings.topP || 0.7
          })
        });
        if (titleResponse.ok) {
          const titleData = await titleResponse.json();
          titleTranslated = ((_i = (_h = (_g = (_f = titleData.choices) == null ? void 0 : _f[0]) == null ? void 0 : _g.message) == null ? void 0 : _h.content) == null ? void 0 : _i.trim()) || article.title;
        }
      } catch (error) {
        console.error("Title translation failed:", error);
      }
    }
    let contentTranslated = article.content_translated || article.content || article.snippet || "";
    if (cleanContent && !translateTitleOnly) {
      const contentPrompt = `\u8BF7\u5C06\u4EE5\u4E0B\u6587\u672C\u7FFB\u8BD1\u6210${targetLanguageName}\uFF0C\u4FDD\u6301\u539F\u6709\u7684HTML\u683C\u5F0F\u548C\u7ED3\u6784\uFF0C\u53EA\u7FFB\u8BD1\u6587\u672C\u5185\u5BB9\uFF0C\u4E0D\u8981\u7FFB\u8BD1HTML\u6807\u7B7E\uFF1A

${cleanContent}`;
      try {
        const contentResponse = await fetch(aiSettings.apiEndpoint || "https://api.siliconflow.cn/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${aiSettings.apiToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            model: aiSettings.model,
            messages: [
              {
                role: "user",
                content: contentPrompt
              }
            ],
            max_tokens: aiSettings.maxTokens || 2e3,
            temperature: aiSettings.temperature || 0.7,
            top_p: aiSettings.topP || 0.7
          })
        });
        if (contentResponse.ok) {
          const contentData = await contentResponse.json();
          contentTranslated = ((_m = (_l = (_k = (_j = contentData.choices) == null ? void 0 : _j[0]) == null ? void 0 : _k.message) == null ? void 0 : _l.content) == null ? void 0 : _m.trim()) || contentTranslated;
        }
      } catch (error) {
        console.error("Content translation failed:", error);
      }
    }
    if (translateTitleOnly) {
      const updateStmt = db.prepare("UPDATE articles SET title_translated = ?, detected_language = ? WHERE id = ?");
      updateStmt.run(titleTranslated, detectedLanguage, articleId);
      return {
        success: true,
        titleTranslated,
        detectedLanguage,
        cached: false
      };
    } else if (translateContentOnly) {
      const updateStmt = db.prepare("UPDATE articles SET content_translated = ?, detected_language = ? WHERE id = ?");
      updateStmt.run(contentTranslated, detectedLanguage, articleId);
      return {
        success: true,
        contentTranslated,
        detectedLanguage,
        cached: false
      };
    } else {
      const updateStmt = db.prepare("UPDATE articles SET title_translated = ?, content_translated = ?, detected_language = ? WHERE id = ?");
      updateStmt.run(titleTranslated, contentTranslated, detectedLanguage, articleId);
      return {
        success: true,
        titleTranslated,
        contentTranslated,
        detectedLanguage,
        cached: false
      };
    }
  } catch (error) {
    console.error("Translate error:", error);
    throw createError({
      statusCode: 500,
      message: error.message || "Failed to translate article"
    });
  }
});

export { translate_post as default };
//# sourceMappingURL=translate.post.mjs.map
