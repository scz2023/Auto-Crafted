import { c as defineEventHandler, g as getQuery, e as createError } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';

const get_get = defineEventHandler(async (event) => {
  var _a;
  const query = getQuery(event);
  const { url } = query;
  if (!url || typeof url !== "string") {
    throw createError({
      statusCode: 400,
      message: "URL is required"
    });
  }
  try {
    const urlObj = new URL(url);
    if (!["http:", "https:"].includes(urlObj.protocol)) {
      throw new Error("Only HTTP and HTTPS URLs are allowed");
    }
    const faviconUrl = `${urlObj.protocol}//${urlObj.host}/favicon.ico`;
    const response = await fetch(faviconUrl, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
      },
      // 设置较短的超时时间，避免长时间等待
      signal: AbortSignal.timeout(5e3)
    });
    if (!response.ok) {
      if (response.status === 404 || response.status === 502) {
        return {
          success: false,
          favicon: null
        };
      }
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }
    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.startsWith("image/")) {
      return {
        success: false,
        favicon: null
      };
    }
    return {
      success: true,
      favicon: faviconUrl
    };
  } catch (error) {
    if (error.name === "AbortError" || ((_a = error.message) == null ? void 0 : _a.includes("timeout"))) {
      return {
        success: false,
        favicon: null,
        error: "timeout"
      };
    }
    return {
      success: false,
      favicon: null,
      error: error.message || "unknown"
    };
  }
});

export { get_get as default };
//# sourceMappingURL=get.get.mjs.map
