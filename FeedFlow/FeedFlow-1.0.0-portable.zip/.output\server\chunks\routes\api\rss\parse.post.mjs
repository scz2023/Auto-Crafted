import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import Parser from 'rss-parser';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';

function normalizeRssUrl(url) {
  if (url.startsWith("rsshub://")) {
    const path = url.replace(/^rsshub:\/\//, "");
    const domainMatch = path.match(/^([^\/]+?)(\/.*)?$/);
    if (domainMatch) {
      const potentialDomain = domainMatch[1];
      const restPath = domainMatch[2] || "";
      if (potentialDomain.includes(".") || potentialDomain.startsWith("localhost")) {
        return `https://${potentialDomain}${restPath}`;
      } else {
        return `https://rsshub.app/${path}`;
      }
    } else {
      return `https://rsshub.app/${path}`;
    }
  }
  if (url.startsWith("rsshub:")) {
    let path = url.replace(/^rsshub:/, "");
    path = path.replace(/^\/+/, "");
    const domainMatch = path.match(/^([^\/]+?)(\/.*)?$/);
    if (domainMatch) {
      const potentialDomain = domainMatch[1];
      const restPath = domainMatch[2] || "";
      if (potentialDomain.includes(".") || potentialDomain.startsWith("localhost")) {
        return `https://${potentialDomain}${restPath}`;
      } else {
        return `https://rsshub.app/${path}`;
      }
    } else {
      return `https://rsshub.app/${path}`;
    }
  }
  return url;
}
const parse_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d, _e, _f;
  const body = await readBody(event);
  let { url, timeout } = body;
  if (!url) {
    throw createError({
      statusCode: 400,
      message: "RSS URL is required"
    });
  }
  url = normalizeRssUrl(url);
  let timeoutValue = timeout || 3e4;
  const parser = new Parser({
    timeout: timeoutValue,
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      "Accept": "application/rss+xml, application/xml, text/xml, */*",
      "Accept-Language": "en-US,en;q=0.9",
      "Accept-Encoding": "gzip, deflate, br",
      "Connection": "keep-alive",
      "Upgrade-Insecure-Requests": "1"
    },
    // 自定义解析器选项，更宽松的解析
    customFields: {
      item: ["media:content", "media:thumbnail"]
    }
  });
  const retryWithBackoff = async (fn, maxRetries = 3, baseDelay = 1e3) => {
    var _a2, _b2, _c2, _d2;
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        return await fn();
      } catch (error) {
        const is429 = error.status === 429 || error.statusCode === 429 || error.code === 429 || ((_a2 = error.message) == null ? void 0 : _a2.includes("429")) || ((_b2 = error.message) == null ? void 0 : _b2.includes("Too Many Requests")) || ((_c2 = error.message) == null ? void 0 : _c2.includes("rate limit")) || ((_d2 = error.message) == null ? void 0 : _d2.includes("Rate limit"));
        if (is429 && attempt < maxRetries - 1) {
          let retryAfter = baseDelay * Math.pow(2, attempt);
          if (error.retryAfter) {
            retryAfter = error.retryAfter * 1e3;
          }
          retryAfter = Math.min(retryAfter, 6e4);
          console.log(`\u9047\u5230 429 \u9519\u8BEF\uFF0C\u7B49\u5F85 ${retryAfter}ms \u540E\u91CD\u8BD5 (\u5C1D\u8BD5 ${attempt + 1}/${maxRetries})`);
          await new Promise((resolve) => setTimeout(resolve, retryAfter));
          continue;
        }
        throw error;
      }
    }
  };
  try {
    const feed = await retryWithBackoff(async () => {
      var _a2, _b2;
      try {
        return await parser.parseURL(url);
      } catch (parseError) {
        if (parseError.code === "ECONNRESET" || ((_a2 = parseError.message) == null ? void 0 : _a2.includes("429")) || ((_b2 = parseError.message) == null ? void 0 : _b2.includes("Too Many Requests")) || parseError.statusCode === 429) {
          const error = new Error(`HTTP 429: Too Many Requests`);
          error.status = 429;
          error.statusCode = 429;
          throw error;
        }
        throw parseError;
      }
    });
    return {
      success: true,
      data: {
        title: feed.title || "",
        description: feed.description || "",
        link: feed.link || "",
        items: feed.items || []
      }
    };
  } catch (error) {
    try {
      const response = await retryWithBackoff(async () => {
        const res = await fetch(url, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Accept": "application/rss+xml, application/xml, text/xml, */*"
          },
          signal: AbortSignal.timeout(timeoutValue)
        });
        if (res.status === 429) {
          const retryAfter = res.headers.get("Retry-After");
          const error2 = new Error(`HTTP 429: Too Many Requests`);
          error2.status = 429;
          if (retryAfter) {
            error2.retryAfter = parseInt(retryAfter, 10);
          }
          throw error2;
        }
        if (!res.ok) {
          throw new Error(`HTTP ${res.status}: ${res.statusText}`);
        }
        const contentType = res.headers.get("content-type") || "";
        if (!contentType.includes("xml") && !contentType.includes("text") && !contentType.includes("application/rss") && !contentType.includes("application/atom")) {
          console.warn(`\u8B66\u544A: \u54CD\u5E94\u7684 Content-Type \u4E0D\u662F XML \u7C7B\u578B: ${contentType}`);
        }
        return res;
      });
      let text = await response.text();
      if (!text || text.length === 0) {
        throw new Error("RSS \u54CD\u5E94\u4E3A\u7A7A");
      }
      if (text.charCodeAt(0) === 65279) {
        text = text.slice(1);
      }
      if (text.length >= 2 && text.charCodeAt(0) === 254 && text.charCodeAt(1) === 255) {
        text = text.slice(2);
      }
      if (text.length >= 2 && text.charCodeAt(0) === 255 && text.charCodeAt(1) === 254) {
        text = text.slice(2);
      }
      text = text.replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/g, "");
      const xmlDeclarationMatch = text.match(/<\?xml[^>]*>/i);
      if (xmlDeclarationMatch) {
        const xmlStartIndex = text.indexOf(xmlDeclarationMatch[0]);
        if (xmlStartIndex > 0) {
          text = text.substring(xmlStartIndex);
        }
      }
      if (!text.startsWith("<?xml") && !text.startsWith("<rss") && !text.startsWith("<feed") && !text.startsWith("<RDF")) {
        const firstTagMatch = text.match(/<[?!]?[a-zA-Z][^>]*>/);
        if (firstTagMatch) {
          const tagStartIndex = text.indexOf(firstTagMatch[0]);
          if (tagStartIndex > 0) {
            text = text.substring(tagStartIndex);
          }
        } else {
          const trimmedText = text.trimStart();
          const trimmedTagMatch = trimmedText.match(/<[?!]?[a-zA-Z][^>]*>/);
          if (trimmedTagMatch) {
            text = trimmedText;
          } else {
            throw new Error("\u54CD\u5E94\u4E0D\u662F\u6709\u6548\u7684 RSS/XML \u683C\u5F0F\uFF1A\u627E\u4E0D\u5230 XML \u6807\u7B7E");
          }
        }
      }
      text = text.trimStart();
      if (!text.startsWith("<?xml") && !text.startsWith("<rss") && !text.startsWith("<feed") && !text.startsWith("<RDF") && !text.startsWith("<!--")) {
        throw new Error("\u54CD\u5E94\u4E0D\u662F\u6709\u6548\u7684 RSS/XML \u683C\u5F0F\uFF1A\u5FC5\u987B\u4EE5 XML \u58F0\u660E\u3001RSS \u6807\u7B7E\u6216\u6CE8\u91CA\u5F00\u59CB");
      }
      try {
        const feed = await parser.parseString(text);
        return {
          success: true,
          data: {
            title: feed.title || "",
            description: feed.description || "",
            link: feed.link || "",
            items: feed.items || []
          }
        };
      } catch (parseError) {
        const errorMessage = parseError.message || "\u672A\u77E5\u9519\u8BEF";
        const firstChars = text.substring(0, 100).replace(/[\x00-\x1F\x7F]/g, (char) => {
          return `[\\x${char.charCodeAt(0).toString(16).padStart(2, "0")}]`;
        });
        console.error("RSS \u89E3\u6790\u5931\u8D25\u8BE6\u60C5:", {
          error: errorMessage,
          firstChars,
          textLength: text.length,
          startsWith: text.substring(0, 50)
        });
        throw new Error(`\u89E3\u6790 RSS \u5931\u8D25: ${errorMessage}\u3002\u54CD\u5E94\u524D100\u4E2A\u5B57\u7B26: ${firstChars}`);
      }
    } catch (fallbackError) {
      const is429 = fallbackError.status === 429 || fallbackError.statusCode === 429 || fallbackError.code === 429 || ((_a = fallbackError.message) == null ? void 0 : _a.includes("429")) || ((_b = fallbackError.message) == null ? void 0 : _b.includes("Too Many Requests")) || ((_c = fallbackError.message) == null ? void 0 : _c.includes("rate limit")) || (error == null ? void 0 : error.status) === 429 || (error == null ? void 0 : error.statusCode) === 429 || (error == null ? void 0 : error.code) === 429 || ((_d = error == null ? void 0 : error.message) == null ? void 0 : _d.includes("429")) || ((_e = error == null ? void 0 : error.message) == null ? void 0 : _e.includes("Too Many Requests")) || ((_f = error == null ? void 0 : error.message) == null ? void 0 : _f.includes("rate limit"));
      if (is429) {
        const retryAfter = fallbackError.retryAfter || (error == null ? void 0 : error.retryAfter);
        const message = retryAfter ? `\u8BF7\u6C42\u9891\u7387\u8FC7\u9AD8\uFF0C\u8BF7\u7B49\u5F85 ${retryAfter} \u79D2\u540E\u91CD\u8BD5\u3002\u5EFA\u8BAE\u589E\u52A0\u5237\u65B0\u95F4\u9694\u65F6\u95F4\u3002` : "\u8BF7\u6C42\u9891\u7387\u8FC7\u9AD8\uFF0C\u8BF7\u7A0D\u540E\u518D\u8BD5\u3002\u5EFA\u8BAE\u589E\u52A0\u5237\u65B0\u95F4\u9694\u65F6\u95F4\u3002";
        throw createError({
          statusCode: 429,
          statusMessage: "Too Many Requests",
          message,
          data: {
            retryAfter: retryAfter || null
          }
        });
      }
      throw createError({
        statusCode: 500,
        message: `\u89E3\u6790 RSS \u5931\u8D25: ${(error == null ? void 0 : error.message) || (fallbackError == null ? void 0 : fallbackError.message) || "\u672A\u77E5\u9519\u8BEF"}`
      });
    }
  }
});

export { parse_post as default };
//# sourceMappingURL=parse.post.mjs.map
