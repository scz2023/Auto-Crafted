import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { u as useDatabase } from '../../../_/database.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';
import 'fs';

const query_post = defineEventHandler(async (event) => {
  try {
    const body = await readBody(event);
    const { sql, params = [] } = body;
    if (!sql) {
      throw createError({
        statusCode: 400,
        message: "SQL query is required"
      });
    }
    let db;
    try {
      db = useDatabase();
    } catch (dbError) {
      console.error("Database connection failed:", dbError);
      throw createError({
        statusCode: 503,
        message: `Database service unavailable: ${dbError.message || "Failed to connect to database"}`
      });
    }
    if (!db) {
      throw createError({
        statusCode: 503,
        message: "Database instance is null"
      });
    }
    try {
      if (sql.trim().toUpperCase().startsWith("SELECT")) {
        const stmt = db.prepare(sql);
        const result = stmt.all(...params);
        return { success: true, data: result };
      } else {
        const stmt = db.prepare(sql);
        const result = stmt.run(...params);
        return {
          success: true,
          data: {
            lastInsertRowid: result.lastInsertRowid,
            changes: result.changes
          }
        };
      }
    } catch (queryError) {
      console.error("Database query error:", queryError);
      console.error("SQL:", sql);
      console.error("Params:", params);
      throw createError({
        statusCode: 500,
        message: `Database query failed: ${queryError.message || "Unknown error"}`
      });
    }
  } catch (error) {
    if (error.statusCode) {
      throw error;
    }
    console.error("Unexpected error in /api/db/query:", error);
    throw createError({
      statusCode: error.statusCode || 500,
      message: error.message || "Internal server error"
    });
  }
});

export { query_post as default };
//# sourceMappingURL=query.post.mjs.map
