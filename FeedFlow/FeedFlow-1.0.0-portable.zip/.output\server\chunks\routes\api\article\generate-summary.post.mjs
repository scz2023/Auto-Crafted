import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import { u as useDatabase } from '../../../_/database.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';
import 'better-sqlite3';
import 'path';
import 'fs';

const generateSummary_post = defineEventHandler(async (event) => {
  var _a, _b, _c, _d;
  const body = await readBody(event);
  const { articleId } = body;
  if (!articleId) {
    throw createError({
      statusCode: 400,
      message: "Article ID is required"
    });
  }
  try {
    const db = useDatabase();
    const stmt = db.prepare("SELECT id, title, content, snippet, ai_summary FROM articles WHERE id = ?");
    const article = stmt.get(articleId);
    if (!article) {
      throw createError({
        statusCode: 404,
        message: "Article not found"
      });
    }
    if (article.ai_summary) {
      return {
        success: true,
        summary: article.ai_summary,
        cached: true
      };
    }
    const settingsStmt = db.prepare("SELECT value FROM settings WHERE key = ?");
    const settingsRow = settingsStmt.get("aiSettings");
    let aiSettings = null;
    if (settingsRow) {
      try {
        aiSettings = JSON.parse(settingsRow.value);
      } catch {
      }
    }
    if (!aiSettings || !aiSettings.apiToken || !aiSettings.model) {
      throw createError({
        statusCode: 400,
        message: "AI settings not configured. Please configure AI settings first."
      });
    }
    const generalSettingsRow = settingsStmt.get("general");
    const aiSummaryRow = settingsStmt.get("aiSummary");
    let aiSummaryEnabled = false;
    if (aiSummaryRow) {
      try {
        const value = JSON.parse(aiSummaryRow.value);
        aiSummaryEnabled = value === true || value === "true" || value === 1;
      } catch {
        aiSummaryEnabled = aiSummaryRow.value === "true" || aiSummaryRow.value === "1";
      }
    }
    if (!aiSummaryEnabled && generalSettingsRow) {
      try {
        const generalSettings = JSON.parse(generalSettingsRow.value);
        aiSummaryEnabled = generalSettings.aiSummary === true || generalSettings.aiSummary === "true" || generalSettings.aiSummary === 1;
      } catch {
      }
    }
    if (!aiSummaryEnabled) {
      throw createError({
        statusCode: 400,
        message: "AI summary is not enabled in settings"
      });
    }
    const contentToSummarize = article.content || article.snippet || article.title;
    if (!contentToSummarize || contentToSummarize.trim().length === 0) {
      throw createError({
        statusCode: 400,
        message: "Article content is empty"
      });
    }
    const textContent = contentToSummarize.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim().substring(0, 8e3);
    const prompt = `\u8BF7\u7528\u4E2D\u6587\u5BF9\u4EE5\u4E0B\u65B0\u95FB\u5185\u5BB9\u8FDB\u884C\u7B80\u6D01\u603B\u7ED3\uFF0C\u603B\u7ED3\u5E94\u8BE5\uFF1A
1. \u7A81\u51FA\u6838\u5FC3\u8981\u70B9
2. \u63A7\u5236\u5728 100-200 \u5B57\u5DE6\u53F3
3. \u4F7F\u7528\u7B80\u6D01\u660E\u4E86\u7684\u8BED\u8A00

\u65B0\u95FB\u6807\u9898\uFF1A${article.title}

\u65B0\u95FB\u5185\u5BB9\uFF1A
${textContent}`;
    const response = await fetch(aiSettings.apiEndpoint || "https://api.siliconflow.cn/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${aiSettings.apiToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: aiSettings.model,
        messages: [
          {
            role: "user",
            content: prompt
          }
        ],
        max_tokens: aiSettings.maxTokens || 500,
        temperature: aiSettings.temperature || 0.7,
        top_p: aiSettings.topP || 0.7
      })
    });
    if (!response.ok) {
      const errorData = await response.text();
      throw new Error(`AI API error: ${response.status} - ${errorData}`);
    }
    const data = await response.json();
    const summary = ((_d = (_c = (_b = (_a = data.choices) == null ? void 0 : _a[0]) == null ? void 0 : _b.message) == null ? void 0 : _c.content) == null ? void 0 : _d.trim()) || "";
    if (!summary) {
      throw new Error("AI API returned empty summary");
    }
    const updateStmt = db.prepare("UPDATE articles SET ai_summary = ? WHERE id = ?");
    updateStmt.run(summary, articleId);
    return {
      success: true,
      summary,
      cached: false
    };
  } catch (error) {
    console.error("Generate summary error:", error);
    throw createError({
      statusCode: 500,
      message: error.message || "Failed to generate summary"
    });
  }
});

export { generateSummary_post as default };
//# sourceMappingURL=generate-summary.post.mjs.map
