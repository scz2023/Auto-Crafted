import { c as defineEventHandler, r as readBody, e as createError } from '../../../_/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'chokidar';
import 'anymatch';
import 'node:crypto';
import 'node:url';

const fetch_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { url } = body;
  if (!url) {
    throw createError({
      statusCode: 400,
      message: "URL is required"
    });
  }
  try {
    const urlObj = new URL(url);
    if (!["http:", "https:"].includes(urlObj.protocol)) {
      throw new Error("Only HTTP and HTTPS URLs are allowed");
    }
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
      }
    });
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    const text = await response.text();
    return {
      success: true,
      data: text
    };
  } catch (error) {
    throw createError({
      statusCode: 500,
      message: error.message || "Failed to fetch OPML from URL"
    });
  }
});

export { fetch_post as default };
//# sourceMappingURL=fetch.post.mjs.map
